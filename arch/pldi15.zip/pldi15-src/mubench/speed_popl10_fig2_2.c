void start(int x, int z, int n)
{
  while (x<n) {
    if (z>x)
      x=x+1;
    else
      z=z+1;
  }
}
