void start(int n)
{
  int flag=1;

  while (flag>0) {
    flag=0;
    while (n>0) {
      n=n-1;       
      flag=1;
    }
  }
}
