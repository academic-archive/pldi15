void start(int x, int y)
{
  while (x < y)
    x++;
  while (y < x)
    y++;
}
