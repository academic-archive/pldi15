void start(int n, int m)
{
  int x=0;
  int y=0;

  while (x<n) {
    if (y<m)
      y=y+1;
    else
      x=x+1;
  }
}
