void start(int n)
{
  int flag = 1;

  while (flag>0) {
    if (n>0) {
      n--;
      flag=1;
    } else
      flag=0;
  }
}
