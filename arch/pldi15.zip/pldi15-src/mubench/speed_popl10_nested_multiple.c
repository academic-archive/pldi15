int nondet();

void start(int x, int n, int y, int m)
{
  while (x<n) {
    while (y<m) {
      if (nondet())
        break;
      y=y+1;
    }
    x=x+1;
  }
}
