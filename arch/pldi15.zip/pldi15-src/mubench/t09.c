#pragma tick

void start(int x) {
	int i,j;
	i=1, j=0;
	while (j<x) {
		j++;
		if (i>=4) {
			i=1;
			tick(40);
		} else
			i++;
		tick(1);
	}
}
