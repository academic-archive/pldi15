void start(int y, int z)
{
  while (z>y) {
    y=y+1;
  }
  while (y>2) {
    y=y-3;
  }
}
