void start(int i, int k)
{
  while (i > 100)
    i--;
  i=i+k+50;
  while (i >= 0)
    i--;
}
